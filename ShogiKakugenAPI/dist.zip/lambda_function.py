import json
import random


class BadRequestError(Exception):
    pass


def lambda_handler(event, context):
    code = event

    if not code:
        raise BadRequestError('BadRequest')

    with open('./resources/prefectures.json', 'r')as f:
        prefectures = json.load(f)

    prefecture = None
    newID = random.randint(1, len(prefectures))

    prefecture = [
        prefecture for prefecture in prefectures if prefecture.get('ID') == newID]

    return prefecture
